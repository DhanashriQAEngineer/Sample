

describe('Sample Test Cases', () => {

    it('Overlapped Element', () => {
        cy.visit('http://uitestingplayground.com/overlapped');
        cy.get('#id').type("EnterId", { force: true })
        cy.get('div[style="overflow-y: scroll; height:100px;"]').scrollTo('bottom');
        cy.get('#name').type("Test", { force: true })
    })

    it('Disabled Input', () => {
        cy.visit('http://uitestingplayground.com/disabledinput');
        cy.get('#inputField').type("EnterId", { force: true })
        cy.get('#enableButton').click({ force: true });
        cy.get('#inputField').should('be.disabled')
        cy.wait(5000);
        cy.get('#inputField').should('not.be.disabled')
    })

    it('Verify Text', () => {
        cy.visit('http://uitestingplayground.com/verifytext');
        cy.get('.badge-secondary span') 
      .should('have.text', 'UserName');
    })

})
  